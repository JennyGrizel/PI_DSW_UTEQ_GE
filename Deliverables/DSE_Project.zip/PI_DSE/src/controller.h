#ifndef CONTROLLER_H_
#define CONTROLLER_H_

extern void calculatePWM(int,int);
extern void setPWM(int);
extern int getPWM(void);

#endif /* CONTROLLER_H_ */
