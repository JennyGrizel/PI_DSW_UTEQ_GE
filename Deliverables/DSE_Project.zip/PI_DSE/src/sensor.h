#ifndef SENSOR_H_
#define SENSOR_H_

extern void readSensor(int);
extern void calculateSpeed(int);
extern void setSpeed(int);
extern int getSpeed(void);


#endif /* SENSOR_H_ */
